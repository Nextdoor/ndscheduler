"""Represents MySQL datastore."""

from ndscheduler.core.datastore.providers import base


class DatastoreMysql(base.DatastoreBase):
    pass
