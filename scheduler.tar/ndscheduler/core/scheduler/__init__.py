"""Customize the core scheduler."""
