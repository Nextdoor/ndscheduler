__version__ = '0.1.0'  # http://semver.org/
