"""Some sample jobs."""
